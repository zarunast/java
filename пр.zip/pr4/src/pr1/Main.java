package pr1;

public class Main {
    public static void main(String[] args) {
        double height = 1.85; // рост в метрах
        double weight = 82;   // вес в килограммах
        double bmi = weight / (height * height);
        System.out.printf("ИМТ: %.2f кг/м²%n", bmi);

        String hometown = "Брянск"; // замените на ваш город
        System.out.println("Родной город: " + hometown);

        double x = 5.75;
        double y = 3.25;
        System.out.println("До обмена: x = " + x + ", y = " + y);
        double temp = x;
        x = y;
        y = temp;
        System.out.println("После обмена: x = " + x + ", y = " + y);
    }
}

