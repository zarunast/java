package pr10;


// Главный класс с main()
public class Main10 {
    public static void main(String[] args) {
        // Создаём объекты конкретных классов
        ConsultingService consult = new ConsultingService("Юридическая консультация", true, 2.0, "Senior");
        CleaningService clean = new CleaningService("Генеральная уборка", true, 4.0, 80.0);

        // Демонстрация обычного метода (унаследован от Service)
        System.out.println("Консультация активна? " + consult.isActive()); // true
        System.out.println("Уборка активна? " + clean.isActive());         // true

        // Вызов абстрактных методов (реализованы в потомках)
        System.out.println("Стоимость консультации: $" + consult.calculateCost()); // 200 * 2 = 400
        System.out.println("Стоимость уборки: $" + clean.calculateCost());         // 25 * 4 = 100

        // Применение скидок
        System.out.println("Консультация со скидкой 20%: $" + consult.applyDiscount(20)); // 320
        System.out.println("Уборка со скидкой 40% (макс. 30%): $" + clean.applyDiscount(40)); // 70

        // Статический метод — генерация ID (проверим уникальность)
        System.out.println("ID консультации: " + consult.id); // 1
        System.out.println("ID уборки: " + clean.id);         // 2

        // Демонстрация цепочки наследования:
        // Service ← TimedService ← ConsultingService / CleaningService
        // Все методы вызываются через полиморфизм
    }

    // Уровень 3: Конкретный класс 2
    static class CleaningService extends TimedService {
        private double areaSize; // в кв. метрах

        public CleaningService(String name, boolean status, double durationHours, double areaSize) {
            super(name, status, durationHours);
            this.areaSize = areaSize;
        }

        @Override
        public double getBaseRate() {
            // Базовая ставка зависит от площади
            if (areaSize <= 50) return 30.0;
            else if (areaSize <= 100) return 25.0;
            else return 20.0;
        }

        @Override
        public double applyDiscount(double discountPercent) {
            double original = calculateCost();
            // Дополнительная логика: скидка не может быть больше 30%
            double maxDiscount = Math.min(discountPercent, 30.0);
            return original * (1 - maxDiscount / 100.0);
        }
    }

    // Уровень 3: Конкретный класс 1
    static class ConsultingService extends TimedService {
        private String expertLevel;

        public ConsultingService(String name, boolean status, double durationHours, String expertLevel) {
            super(name, status, durationHours);
            this.expertLevel = expertLevel;
        }

        @Override
        public double getBaseRate() {
            switch (expertLevel) {
                case "Junior":
                    return 50.0;
                case "Middle":
                    return 100.0;
                case "Senior":
                    return 200.0;
                default:
                    return 75.0;
            }
        }

        @Override
        public double applyDiscount(double discountPercent) {
            double original = calculateCost();
            return original * (1 - discountPercent / 100.0);
        }
    }

    // Уровень 1: Базовый абстрактный класс
    abstract static class Service {
        protected static int nextId = 1;
        protected int id;
        protected String name;
        protected boolean status; // true = активна

        public Service(String name, boolean status) {
            this.id = generateId();
            this.name = name;
            this.status = status;
        }

        // Статический метод — генерация уникального ID
        public static int generateId() {
            return nextId++;
        }

        // Обычный метод — проверка активности
        public boolean isActive() {
            return status;
        }

        // Абстрактные методы
        public abstract double calculateCost();
        public abstract double applyDiscount(double discountPercent);
    }

    // Уровень 2: Промежуточный абстрактный класс
    abstract static class TimedService extends Service {
        protected double durationHours;

        public TimedService(String name, boolean status, double durationHours) {
            super(name, status);
            this.durationHours = durationHours;
        }

        // Реализует calculateCost(), но требует getBaseRate() от потомков
        @Override
        public double calculateCost() {
            return getBaseRate() * durationHours;
        }

        // Новый абстрактный метод
        public abstract double getBaseRate();
    }
}