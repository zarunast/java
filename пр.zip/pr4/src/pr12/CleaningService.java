package pr12;

class CleaningService extends TimedService {
    private double area;

    public CleaningService(String name, boolean isActive, double durationHours, double area) {
        super(name, isActive, durationHours);
        this.area = area;
    }

    @Override
    public double getBaseRate() {
        if (area <= 50) return 40.0;
        else if (area <= 100) return 30.0;
        else return 20.0;
    }

    @Override
    public double applyDiscount(double percent) {
        double cost = calculateCost();
        return cost * (1 - Math.min(percent, 20) / 100.0);
    }
}
