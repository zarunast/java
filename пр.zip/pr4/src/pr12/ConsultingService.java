package pr12;

class ConsultingService extends TimedService {
    private String expertLevel;

    public ConsultingService(String name, boolean isActive, double durationHours, String expertLevel) {
        super(name, isActive, durationHours);
        this.expertLevel = expertLevel;
    }

    @Override
    public double getBaseRate() {
        return switch (expertLevel) {
            case "Junior" -> 50.0;
            case "Middle" -> 100.0;
            case "Senior" -> 200.0;
            default -> 75.0;
        };
    }

    @Override
    public double applyDiscount(double percent) {
        double cost = calculateCost();
        return cost * (1 - Math.min(percent, 50) / 100.0); // макс. скидка 50%
    }
}
