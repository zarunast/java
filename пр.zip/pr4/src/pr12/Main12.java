package pr12;

public class Main12 {
    public static void processService(Service s) {
        s.displayInfo();
        System.out.println("Стоимость: $" + s.calculateCost());
        System.out.println("Со скидкой 25%: $" + s.applyDiscount(25));
        System.out.println("---");
    }

    public static void main(String[] args) {
        ConsultingService consult = new ConsultingService("Юридическая консультация", true, 2.0, "Senior");
        CleaningService clean = new CleaningService("Уборка квартиры", true, 3.0, 75.0);

        processService(consult);
        processService(clean);

        System.out.println("Следующий ID будет: " + Service.generateId());
    }
}