package pr12;
// Базовый абстрактный класс — уровень 1
abstract class Service {
    protected int id;
    protected String name;
    protected boolean isActive;

    private static int counter = 1;
    public static int generateId() {
        return counter++;
    }

    public Service(String name, boolean isActive) {
        this.id = generateId();
        this.name = name;
        this.isActive = isActive;
    }

    public void displayInfo() {
        System.out.println("Услуга: " + name + " (ID: " + id + "), активна: " + isActive);
    }

    public abstract double calculateCost();
    public abstract double applyDiscount(double percent);
}


