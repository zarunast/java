package pr12;

abstract class TimedService extends Service {
    protected double durationHours;

    public TimedService(String name, boolean isActive, double durationHours) {
        super(name, isActive);
        this.durationHours = durationHours;
    }
    @Override
    public double calculateCost() {
        return getBaseRate() * durationHours;
    }
    public abstract double getBaseRate();
}
