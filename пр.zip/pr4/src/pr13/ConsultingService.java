package pr13;

// ======================
// 4. Конкретный класс, реализующий интерфейс
// ======================
class ConsultingService extends TimedService implements Discountable {
    private String expertLevel; // "Junior", "Middle", "Senior"

    public ConsultingService(String name, boolean isActive, double durationHours, String expertLevel) {
        super(name, isActive, durationHours);
        this.expertLevel = expertLevel;
    }

    @Override
    public double getBaseRate() {
        return switch (expertLevel) {
            case "Junior" -> 50.0;
            case "Middle" -> 100.0;
            case "Senior" -> 200.0;
            default -> 75.0;
        };
    }

    // Реализация метода из интерфейса
    @Override
    public double applyDiscount(double percent) {
        if (!isDiscountApplicable()) return calculateCost();
        double maxDiscount = Math.min(percent, 40); // макс. скидка 40%
        return calculateCost() * (1 - maxDiscount / 100.0);
    }

    // Можно (но не обязательно) переопределить default-метод
    @Override
    public boolean isDiscountApplicable() {
        return isActive; // скидка только если услуга активна
    }
}
