package pr13;
// ======================
// 1. Интерфейс Discountable
// ======================
interface Discountable {
    // Абстрактный метод — ОБЯЗАТЕЛЬНО реализовать
    double applyDiscount(double percent);

    // Default-метод (появился в Java 8)
    default boolean isDiscountApplicable() {
        return true; // по умолчанию скидка разрешена
    }

    // Статический метод в интерфейсе (можно!)
    static String formatCurrency(double amount) {
        return String.format("$%.2f", amount);
    }
}

