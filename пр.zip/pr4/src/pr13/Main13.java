package pr13;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
// ======================
// Главный класс
// ======================
public class Main13 {
    // Полиморфный метод: принимает любой Service
    public static void showServiceInfo(Service s) {
        s.displayBasicInfo(); // обычный метод
        System.out.println("Стоимость: " + Discountable.formatCurrency(s.calculateCost())); // статик из интерфейса
    }

    // Метод, принимающий интерфейсный тип — демонстрация полиморфизма
    public static void processDiscount(Discountable d) {
        System.out.println("Скидка 30% → " + Discountable.formatCurrency(d.applyDiscount(30)));
        System.out.println("Скидка разрешена? " + d.isDiscountApplicable());
    }

    public static void main(String[] args) {
        // Создание объекта
        ConsultingService service = new ConsultingService("IT-консультация", true, 2.5, "Senior");

        // 1. Переменная типа абстрактного класса
        Service svcRef = service;
        showServiceInfo(svcRef);

        // 2. Переменная типа конкретного класса
        service.displayBasicInfo();

        // 3. Переменная типа интерфейса
        Discountable discRef = service;
        processDiscount(discRef);

        // Статический метод из абстрактного класса
        System.out.println("Следующий ID: " + Service.generateId());

        System.out.println("\n--- Демонстрация полиморфизма ---");
        // Один и тот же объект — три разных типа ссылок
        // Всё работает, потому что:
        // - наследование связывает Service → TimedService → ConsultingService
        // - интерфейс добавляет поведение "скидка"
    }
}