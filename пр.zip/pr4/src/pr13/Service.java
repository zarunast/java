package pr13;

// ======================
// 2. Базовый абстрактный класс
// ======================
abstract class Service {
    protected int id;
    protected String name;
    protected boolean isActive;

    private static int counter = 1;

    public Service(String name, boolean isActive) {
        this.id = generateId();
        this.name = name;
        this.isActive = isActive;
    }

    // Статический метод (в абстрактном классе)
    public static int generateId() {
        return counter++;
    }

    // Обычный (неабстрактный) метод
    public void displayBasicInfo() {
        System.out.println("Услуга: " + name + " | ID: " + id + " | Активна: " + isActive);
    }

    // Абстрактный метод — поведение уточняется потомками
    public abstract double calculateCost();
}
