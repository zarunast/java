package pr13;

// ======================
// 3. Промежуточный абстрактный класс
// ======================
abstract class TimedService extends Service {
    protected double durationHours;

    public TimedService(String name, boolean isActive, double durationHours) {
        super(name, isActive);
        this.durationHours = durationHours;
    }

    // Частичная реализация: использует getBaseRate() из потомков
    @Override
    public double calculateCost() {
        return getBaseRate() * durationHours;
    }

    // Новый абстрактный метод
    public abstract double getBaseRate();
}
