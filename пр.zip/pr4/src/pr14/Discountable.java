package pr14;

public interface Discountable {
    double applyDiscount(double percent);

    default boolean isDiscountApplicable() {
        return true;
    }

    static String formatCurrency(double amount) {
        return String.format("$%.2f", amount);
    }
}
