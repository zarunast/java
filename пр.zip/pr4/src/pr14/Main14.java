package pr14;

public class Main14 {

    public static void showServiceInfo(Service s) {
        s.displayBasicInfo();
        System.out.println("Стоимость: " + Discountable.formatCurrency(s.calculateCost()));
    }

    public static void processDiscount(Discountable d) {
        System.out.println("Скидка 30% → " + Discountable.formatCurrency(d.applyDiscount(30)));
        System.out.println("Скидка разрешена? " + d.isDiscountApplicable());
    }

    public static void main(String[] args) {
        ConsultingService service = new ConsultingService("IT-консультация", true, 2.5, "Senior");

        System.out.println("=== 1. Восходящее приведение (Upcasting) ===");
        Service svcRef = service;
        showServiceInfo(svcRef);

        Discountable discRef = service;
        processDiscount(discRef);

        System.out.println("\n=== 2. Нисходящее приведение (Downcasting) с instanceof ===");
        if (svcRef instanceof ConsultingService) {
            ConsultingService downcasted = (ConsultingService) svcRef;
            System.out.println("Успешный downcast! Уровень эксперта: " + downcasted.getExpertLevel());
        }

        if (discRef instanceof TimedService) {
            TimedService timed = (TimedService) discRef;
            System.out.println("Продолжительность: " + timed.durationHours + " часов");
        }

        System.out.println("\n=== 3. Проверка через instanceof перед приведением ===");
        Service juniorRef = new ConsultingService("Анализ данных", false, 1.0, "Junior");
        if (juniorRef instanceof Discountable d) {
            System.out.println("Скидка для неактивной услуги: " + Discountable.formatCurrency(d.applyDiscount(25)));
        }

        System.out.println("\n=== 4. Следующий ID (статический метод) ===");
        System.out.println("Следующий ID: " + Service.generateId());

        System.out.println("\n=== 5. Полиморфизм: один объект — три ссылки ===");
        System.out.println("svcRef.getClass(): " + svcRef.getClass().getSimpleName());
        System.out.println("discRef.getClass(): " + discRef.getClass().getSimpleName());
        System.out.println("service.getClass(): " + service.getClass().getSimpleName());
    }
}