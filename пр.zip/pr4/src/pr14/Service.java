package pr14;

public abstract class Service {
    protected int id;
    protected String name;
    protected boolean isActive;

    private static int counter = 1;

    public Service(String name, boolean isActive) {
        this.id = generateId();
        this.name = name;
        this.isActive = isActive;
    }

    public static int generateId() {
        return counter++;
    }

    public void displayBasicInfo() {
        System.out.println("Услуга: " + name + " | ID: " + id + " | Активна: " + isActive);
    }

    public abstract double calculateCost();
}
