package pr15_16;

class ConsultingService extends TimedService {
    private ServiceType type;
    private String expertLevel;
    public String getExpertLevel() {
        return expertLevel;
    }

    public ConsultingService(String name, boolean isActive, double durationHours,
                             ServiceType type, String expertLevel) {
        super(name, isActive, durationHours);
        if (!type.isActive()) {
            throw new IllegalArgumentException("Тип услуги недоступен: " + type);
        }
        this.type = type;
        this.expertLevel = expertLevel;
    }

    @Override
    public double getBaseRate() {
        return type.getBaseRate();
    }

    @Override
    public double calculateCost() {
        double base = super.calculateCost();
        if ("Junior".equals(expertLevel)) {
            return base * 0.9; // скидка 10%
        }
        return base;
    }

    public void changeType(ServiceType newType) {
        if (!type.canSwitchTo(newType)) {
            throw new IllegalStateException("Нельзя переключиться на: " + newType);
        }
        this.type = newType;
        System.out.println("🔄 Тип изменён на: " + newType);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Тип: " + type + " | Уровень эксперта: " + expertLevel);
    }
}
