package pr15_16;


public class Main {
    public static void main(String[] args) {
        ConsultingService service = new ConsultingService(
                "IT-консультация", true, 2.0, ServiceType.CONSULTING, "Senior"
        );
        service.displayInfo();
        System.out.println("Стоимость: $" + service.calculateCost());

        Service svcRef = service;
        TimedService timedRef = service;
        svcRef.displayInfo();

        if (svcRef instanceof ConsultingService cs) {
            System.out.println("Уровень эксперта: " + cs.getExpertLevel());
            cs.changeType(ServiceType.DELIVERY);
        }

        try {
            Service dummy = new Service("Тест", true) {
                @Override
                public double calculateCost() {
                    return 100.0; }
            };
            ConsultingService bad = (ConsultingService) dummy;
        } catch (ClassCastException e) {
            System.err.println("❌ ClassCastException: " + e.getMessage());
        }

        Promotable promo1 = new Promotable() {
            @Override
            public String promote() {
                return "🔥 Специальное предложение: " + service.name + " за $" +
                        (service.calculateCost() * 0.8) + "!";
            }
        };
        System.out.println(promo1.promote());

        TimedService anonService = new TimedService("Экспресс-поддержка", true, 0.5) {
            @Override
            public double getBaseRate() {
                return 180.0;
            }
        };
        System.out.println("Экспресс-услуга: $" + anonService.calculateCost());

        Service.Transaction tx = service.new Transaction(300.0, "Оплата консультации");
        tx.log();

        System.out.println("Валидация длительности: " +
                Service.Validator.isValidDuration(5.0));

        service.processPayment(250.0);

        System.out.println("\nВсе типы услуг:");
        for (ServiceType t : ServiceType.values()) {
            System.out.printf("- %s → активен: %s%n", t, t.isActive());
        }

        ServiceType fromString = ServiceType.valueOf("DELIVERY");
        System.out.println("Получено из строки: " + fromString);
    }
}
