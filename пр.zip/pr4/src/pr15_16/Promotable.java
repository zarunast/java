package pr15_16;

interface Promotable {
    String promote();
}
