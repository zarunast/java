package pr15_16;

abstract class Service {
    protected int id;
    protected String name;
    protected boolean isActive;

    private static int nextId = 1;

    public Service(String name, boolean isActive) {
        this.id = generateId();
        this.name = name;
        this.isActive = isActive;
    }

    public static int generateId() {
        return nextId++;
    }

    public void displayInfo() {
        System.out.println("Услуга: " + name + " | ID: " + id + " | Активна: " + isActive);
    }

    public abstract double calculateCost();

    public class Transaction {
        private double amount;
        private String description;

        public Transaction(double amount, String description) {
            this.amount = amount;
            this.description = description;
        }

        public void log() {
            System.out.printf("Транзакция: %s | $%.2f | Услуга: %s (ID=%d)%n",
                    description, amount, Service.this.name, Service.this.id);
        }
    }

    public static class Validator {
        public static boolean isValidDuration(double hours) {
            return hours > 0;
        }
    }

    public void processPayment(double amount) {
        class PaymentProcessor {
            void execute() {
                if (amount <= 0) {
                    System.out.println("❌ Ошибка: сумма должна быть > 0");
                } else {
                    System.out.printf("✅ Платёж на $%.2f для '%s' обработан%n", amount, name);
                }
            }
        }
        new PaymentProcessor().execute();
    }
}
