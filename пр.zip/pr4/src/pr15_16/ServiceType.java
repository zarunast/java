package pr15_16;

enum ServiceType {
    INTERNET("Интернет-услуги", 300.0, true),
    DELIVERY("Доставка", 200.0, true),
    CLEANING("Уборка", 250.0, true),
    CONSULTING("Консультации", 500.0, false); // временно недоступен

    private final String description;
    private final double baseRate;
    private final boolean isActive;

    ServiceType(String description, double baseRate, boolean isActive) {
        this.description = description;
        this.baseRate = baseRate;
        this.isActive = isActive;
    }

    public String getDescription() {
        return description;
    }

    public double getBaseRate() {
        return baseRate;
    }

    public boolean isActive() {
        return isActive;
    }

    public boolean canSwitchTo(ServiceType other) {
        return other != null && other.isActive();
    }

    @Override
    public String toString() {
        return name() + " (" + description + ")";
    }
}
