package pr15_16;

abstract class TimedService extends Service {
    protected double durationHours;

    public TimedService(String name, boolean isActive, double durationHours) {
        super(name, isActive);
        if (!Service.Validator.isValidDuration(durationHours)) {
            throw new IllegalArgumentException("Длительность должна быть > 0");
        }
        this.durationHours = durationHours;
    }

    @Override
    public double calculateCost() {
        return getBaseRate() * durationHours;
    }

    public abstract double getBaseRate();
}


