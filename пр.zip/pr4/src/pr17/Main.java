package pr17;
import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {

        Service internet = new Service(
                "Гигабит",
                LocalDateTime.of(2025, 12, 15, 14, 0),
                1200.0,
                ServiceType.INTERNET
        );

        System.out.println(ServiceType.INTERNET.getName());



        Service delivery = new Service(
                "Экспресс",
                LocalDateTime.of(2025, 12, 10, 10, 30),
                500.0,
                ServiceType.DELIVERY
        );

        Service cleaning = new Service(
                "Генеральная",
                LocalDateTime.of(2025, 12, 20, 9, 0),
                3000.0,
                ServiceType.CLEANING
        );

        System.out.println("Исходные услуги:");
        System.out.println(internet);
        System.out.println(delivery);
        System.out.println(cleaning);

        System.out.println("\nПрименение скидок:");
        if (internet.applyDiscount(10)) {
            System.out.println("Скидка 10% применена к интернету: " + internet.getCost());
        }
        if (delivery.applyDiscount(20)) {
            System.out.println("Скидка 20% применена к доставке");
        } else {
            System.out.println("Скидка 20% НЕДОПУСТИМА для доставки");
        }
        if (!cleaning.applyDiscount(5)) {
            System.out.println("Уборка: скидки запрещены — скидка 5% отклонена");
        }

        System.out.println("\nВсе типы услуг:");
        for (ServiceType type : ServiceType.values()) {
            System.out.println("- " + type.getName() + ": " + type.getDescription());
        }

        try {
            ServiceType restored = ServiceType.fromName("Доставка");
            System.out.println("\nВосстановлен тип: " + restored);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }

    }
}
/*
* // Получаем все типы услуг
ServiceType[] всеУслуги = ServiceType.values();
// Ищем тип услуги по названию
ServiceType услуга = ServiceType.valueOf("INTERNET");
* // Пример использования
ServiceType интернет = ServiceType.INTERNET;
int номер = интернет.ordinal(); // Вернёт 0
* ServiceType уборка = ServiceType.CLEANING;
String название = уборка.name();
*/