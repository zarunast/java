package pr17;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Service {
    private String tariff;
    private LocalDateTime serviceTime;
    private double cost;
    private ServiceType type;


    public Service(String tariff, LocalDateTime serviceTime, double cost, ServiceType type) {
        this.tariff = tariff;
        this.serviceTime = serviceTime;
        this.cost = cost;
        this.type = type;
    }


    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        this.tariff = tariff;
    }

    public LocalDateTime getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(LocalDateTime serviceTime) {
        this.serviceTime = serviceTime;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public ServiceType getType() {
        return type;
    }

    public void setType(ServiceType newType) {
        // Пока логика простая, но можно добавить ограничения
        this.type = newType;
    }


    public boolean applyDiscount(double discountPercent) {
        if (type.isDiscountAllowed(discountPercent)) {
            double discount = cost * (discountPercent / 100.0);
            this.cost -= discount;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        return String.format(
                "Услуга{тип='%s', тариф='%s', время='%s', стоимость=%.2f}",
                type.getName(), tariff, serviceTime.format(formatter), cost
        );
    }
}
