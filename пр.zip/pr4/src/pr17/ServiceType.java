package pr17;

public enum ServiceType {
    INTERNET("Интернет", "Высокоскоростной доступ в интернет"),
    DELIVERY("Доставка", "Курьерская доставка товаров"),
    CLEANING("Уборка", "Профессиональная уборка помещений");

    private final String name;
    private final String description;

    ServiceType(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }


    public boolean isDiscountAllowed(double discountPercent) {
        switch (this) {
            case INTERNET:
                return discountPercent >= 0 && discountPercent <= 10.0;
            case DELIVERY:
                return discountPercent >= 0 && discountPercent <= 15.0;
            case CLEANING:
                return discountPercent == 0.0;
            default:
                return false;
        }
    }

    public static ServiceType fromName(String name) {
        for (ServiceType type : ServiceType.values()) {
            if (type.getName().equalsIgnoreCase(name)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Неизвестный тип услуги: " + name);
    }
}