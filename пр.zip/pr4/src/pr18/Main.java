package pr18;
import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        // Создаём услуги
        Service internet = new Service("Гигабит", LocalDateTime.of(2025, 12, 10, 14, 0), 1200.0, ServiceType.INTERNET);
        Service delivery = new Service("Экспресс", LocalDateTime.of(2025, 12, 11, 10, 30), 500.0, ServiceType.DELIVERY);
        Service cleaning = new Service("Генеральная", LocalDateTime.of(2025, 12, 12, 9, 0), 3000.0, ServiceType.CLEANING);

        // Демонстрация перечисления и изменения типа
        System.out.println("=== Демонстрация enum и Service ===");
        System.out.println(internet);
        System.out.println(delivery);

        // Попытка изменить тип
        delivery.setType(ServiceType.CLEANING); // разрешено
        System.out.println("После смены типа: " + delivery);

        // Попытка запрещённого перехода
        try {
            cleaning.setType(ServiceType.INTERNET); // запрещено логикой enum
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
        System.out.println("\n=== Демонстрация generics ===");
        ServiceContainer<Service> container = new ServiceContainer<>(internet);
        container.printCurrent();

        container.addService(delivery);
        container.printCurrent();

        // Вывод истории
        System.out.println("\nИстория услуг:");
        for (Service s : container.getHistory()) {
            System.out.println(" - " + s);
        }

    }
}