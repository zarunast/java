package pr18;
import java.time.LocalDateTime;

public class Service {
    private String tariff;
    private LocalDateTime serviceTime;
    private double cost;
    private ServiceType type;

    public Service(String tariff, LocalDateTime serviceTime, double cost, ServiceType type) {
        this.tariff = tariff;
        this.serviceTime = serviceTime;
        this.cost = cost;
        this.type = type;
    }

    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        this.tariff = tariff;
    }

    public LocalDateTime getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(LocalDateTime serviceTime) {
        this.serviceTime = serviceTime;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public ServiceType getType() {
        return type;
    }

    /**
     * Изменение типа услуги с проверкой через метод enum
     */
    public void setType(ServiceType newType) {
        if (this.type.canChangeTo(newType)) {
            this.type = newType;
        } else {
            throw new IllegalArgumentException(
                    "Недопустимый переход: " + this.type.getName() + " → " + newType.getName()
            );
        }
    }

    @Override
    public String toString() {
        return String.format(
                "Service{тариф='%s', время='%s', стоимость=%.2f, тип=%s}",
                tariff,
                serviceTime != null ? serviceTime.toString() : "не задано",
                cost,
                type.getName()
        );
    }
}