package pr18;
import java.util.ArrayList;
import java.util.List;

public class ServiceContainer<T extends Service> {
    private T currentService;
    private List<T> history;

    public ServiceContainer(T service) {
        this.currentService = service;
        this.history = new ArrayList<>();
        this.history.add(service);
    }

    public void addService(T service) {
        this.currentService = service;
        this.history.add(service);
    }

    public T getCurrentService() {
        return currentService;
    }

    public List<T> getHistory() {
        return new ArrayList<>(history); // защита от внешнего изменения
    }

    public void printCurrent() {
        System.out.println("Текущая услуга: " + currentService);
    }
}