package pr18;
public enum ServiceType {
    INTERNET(1, "Интернет", "Высокоскоростной доступ в интернет"),
    DELIVERY(2, "Доставка", "Курьерская доставка товаров"),
    CLEANING(3, "Уборка", "Профессиональная уборка помещений");

    private final int id;
    private final String name;
    private final String description;

    ServiceType(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }


    public boolean canChangeTo(ServiceType newType) {
        // Пример бизнес-логики: из уборки нельзя сразу перейти в интернет
        if (this == CLEANING && newType == INTERNET) {
            return false;
        }
        return true; // остальные переходы разрешены
    }

    @Override
    public String toString() {
        return name + " (" + description + ")";
    }
}