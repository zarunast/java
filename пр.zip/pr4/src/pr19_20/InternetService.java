package pr19_20;

public class InternetService extends Service {
    private double speedMbps;

    public InternetService(String tariff, int durationMinutes, double baseCost, double discountPercent, double speedMbps) {
        super(tariff, durationMinutes, baseCost, discountPercent);
        setSpeedMbps(speedMbps);
    }

    public double getSpeedMbps() {
        return speedMbps;
    }

    public void setSpeedMbps(double speedMbps) {
        if (speedMbps <= 0)
            throw new IllegalArgumentException("Скорость должна быть положительной");
        this.speedMbps = speedMbps;
    }

    @Override
    public double calculateFinalCost() {
        double extra = speedMbps > 100 ? getBaseCost() * 0.1 : 0;
        return super.calculateFinalCost() + extra;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" [Интернет, скорость=%.1f Мбит/с]", speedMbps);
    }
}
