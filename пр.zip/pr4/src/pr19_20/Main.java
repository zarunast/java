package pr19_20;

import java.io.*;
import java.util.*;

public class Main {
    private static final String DIR_NAME = "lab_output";
    private static final String FILE_NAME = "services.txt";

    public static void main(String[] args) {
        LinkedList<Service> services = new LinkedList<>();
        services.add(new Service("Базовый", 60, 500.0, 0));
        services.add(new InternetService("Оптика", 120, 800.0, 5.0, 200));
        services.add(new MobileService("Мобильный+", 30, 400.0, 15.0, 1200));
        services.addFirst(new Service("Старт", 30, 200.0, 10.0));
        services.addLast(new MobileService("Эконом", 20, 100.0, 0, 100));

        services.removeIf(s -> s.getDiscountPercent() > 10);
        writeServicesToFile(services, DIR_NAME, FILE_NAME);
        readServicesFromFile(DIR_NAME, FILE_NAME);
    }
    public static void writeServicesToFile(LinkedList<Service> list, String dirName, String fileName) {
        File dir = new File(dirName);
        if (!dir.exists()) {
            boolean created = dir.mkdirs();
            if (created && dir.exists() && dir.isDirectory()) {
                System.out.println("Директория создана: " + dir.getAbsolutePath());
            } else {
                System.err.println(" Не удалось создать директорию");
                return;
            }
        }

        File file = new File(dir, fileName);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) {
            for (Service s : list) {
                writer.write(s.toString());
                writer.newLine();
            }
            System.out.println("Запись в файл выполнена: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Ошибка записи: " + e.getMessage());
        }
    }
    public static void readServicesFromFile(String dirName, String fileName) {
        File file = new File(dirName, fileName);

        if (!file.exists()) {
            System.out.println("Файл не найден: " + file.getAbsolutePath());
            return;
        }

        System.out.println("\n--- Чтение файла ---");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 1;
            while ((line = reader.readLine()) != null) {
                System.out.println("Строка " + lineNumber + ": " + line);
                lineNumber++;
            }
            System.out.println(" Чтение файла завершено");
        } catch (IOException e) {
            System.err.println("Ошибка чтения: " + e.getMessage());
        }
    }
}
