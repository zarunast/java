package pr19_20;

public class MobileService extends Service {
    private int includedMinutes;

    public MobileService(String tariff, int durationMinutes, double baseCost, double discountPercent, int includedMinutes) {
        super(tariff, durationMinutes, baseCost, discountPercent);
        setIncludedMinutes(includedMinutes);
    }

    public int getIncludedMinutes() { return includedMinutes; }
    public void setIncludedMinutes(int includedMinutes) {
        if (includedMinutes < 0)
            throw new IllegalArgumentException("Минуты не могут быть отрицательными");
        this.includedMinutes = includedMinutes;
    }

    @Override
    public double calculateFinalCost() {
        return super.calculateFinalCost() * (includedMinutes >= 1000 ? 1.2 : 1.0);
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" [Мобильная связь, минуты=%d%s]",
                includedMinutes, includedMinutes >= 1000 ? " — безлимит" : "");
    }
}