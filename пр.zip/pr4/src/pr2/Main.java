package pr2;

public class Main {
    public static void main(String[] args) {
        System.out.println("Первые 10 степеней числа 2:");
        for (int i = 1; i <= 10; i++) {
            double result = Math.pow(2, i);
            System.out.printf("2^%d = %.0f%n", i, result);
        }
    }
}
