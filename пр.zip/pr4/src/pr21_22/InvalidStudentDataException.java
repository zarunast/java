package pr21_22;

// Проверяемое (checked) исключение — наследуем от Exception
public class InvalidStudentDataException extends Exception {
    public InvalidStudentDataException(String message) {
        super(message);
    }
}
