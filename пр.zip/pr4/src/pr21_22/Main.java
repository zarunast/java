package pr21_22;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList<>();

        System.out.println("=== Создание студентов с валидацией ===");
        try {
            students.add(new Student("Анна", 20, 4.5));
            students.add(new Student("Борис", 22, 3.7));
            students.add(new Student("", 18, 4.0)); // ❌ Пустое имя → исключение!
        } catch (InvalidStudentDataException e) {
            System.err.println("❌ Ошибка при создании студента: " + e.getMessage());
        }

        // === 2. Добавим ещё студентов (без ошибок) ===
        try {
            students.add(new Student("Вера", 19, 4.8));
            students.add(new Student("Глеб", 21, -1.0)); // ❌ Неверный GPA
        } catch (InvalidStudentDataException e) {
            System.err.println("❌ Ошибка: " + e.getMessage());
        }

        // === 3. Демонстрация unchecked-исключения (ArrayIndexOutOfBoundsException) ===
        System.out.println("\n=== Попытка получить несуществующий элемент ===");
        try {
            Student fake = students.get(100); // индекс вне диапазона
        } catch (IndexOutOfBoundsException e) {
            System.err.println("⚠️  Поймано unchecked-исключение: " + e.getClass().getSimpleName() + " — " + e.getMessage());
        }

        // === 4. Ввод данных от пользователя с обработкой InputMismatchException ===
        System.out.println("\n=== Ввод возраста через Scanner ===");
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Введите возраст студента: ");
            int userAge = scanner.nextInt(); // если ввести "abc" → InputMismatchException
            try {
                students.add(new Student("Новый", userAge, 4.0));
                System.out.println("✅ Студент добавлен.");
            } catch (InvalidStudentDataException e) {
                System.err.println("❌ Некорректные данные: " + e.getMessage());
            }
        } catch (InputMismatchException e) {
            System.err.println("❌ Вы ввели не число! Ошибка: " + e.getMessage());
        } finally {
            scanner.close(); // освобождаем ресурс
            System.out.println("Scanner закрыт (finally).");
        }

        // === 5. Использование throws в методе (демонстрация) ===
        System.out.println("\n=== Сохранение студентов в файл ===");
        try {
            for (Student s : students) {
                if (s != null) {
                    s.saveToFile("students.txt"); // может бросить IOException
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Не удалось записать в файл: " + e.getMessage());
            e.printStackTrace(); // логируем стек для отладки (не "проглатываем"!)
        }

        // === 6. Использование contains(), get(), remove() — как в ArrayList-лабе ===
        System.out.println("\n=== Работа со списком ===");
        System.out.println("Размер списка: " + students.size());

        if (!students.isEmpty()) {
            try {
                Student first = students.get(0);
                System.out.println("Первый студент: " + first.getName());

                // Удалим студента по значению
                Student toRemove = new Student("Анна", 20, 4.5);
                if (students.contains(toRemove)) {
                    students.remove(toRemove);
                    System.out.println("Студент 'Анна' удалён.");
                }

                // Поиск студента с GPA > 4.7
                Student highGpa = null;
                for (Student s : students) {
                    if (s != null && s.getGpa() > 4.7) {
                        highGpa = s;
                        break;
                    }
                }
                if (highGpa != null) {
                    System.out.println("Найден студент с высоким GPA: " + highGpa);
                } else {
                    System.out.println("Студентов с GPA > 4.7 не найдено.");
                }
            } catch (Exception e) { // общая обработка на крайний случай (не злоупотреблять!)
                System.err.println("Неожиданная ошибка: " + e.getMessage());
            }
        }

        // === 7. Очистка и финальный вывод ===
        students.clear();
        System.out.println("\n✅ Список очищен. Размер: " + students.size());

        // Демонстрация finally вне try-catch — просто как гарантия выполнения
        try {
            // пусто
        } finally {
            System.out.println("🔹 Программа завершена. Все ресурсы обработаны.");
        }
    }
}