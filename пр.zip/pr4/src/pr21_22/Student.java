package pr21_22;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Student {
    private String name;
    private int age;
    private double gpa;

    // Конструктор с проверкой через исключение
    public Student(String name, int age, double gpa) throws InvalidStudentDataException {
        setName(name);
        setAge(age);
        setGpa(gpa);
    }

    // Валидация имени
    public void setName(String name) throws InvalidStudentDataException {
        if (name == null || name.trim().isEmpty()) {
            throw new InvalidStudentDataException("Имя студента не может быть пустым или null");
        }
        this.name = name.trim();
    }

    // Валидация возраста
    public void setAge(int age) throws InvalidStudentDataException {
        if (age < 14 || age > 100) {
            throw new InvalidStudentDataException("Возраст студента должен быть от 14 до 100 лет, получено: " + age);
        }
        this.age = age;
    }

    // Валидация GPA (среднего балла)
    public void setGpa(double gpa) throws InvalidStudentDataException {
        if (gpa < 0.0 || gpa > 5.0) {
            throw new InvalidStudentDataException("GPA должен быть в диапазоне [0.0, 5.0], получено: " + gpa);
        }
        this.gpa = gpa;
    }

    // Геттеры
    public String getName() { return name; }
    public int getAge() { return age; }
    public double getGpa() { return gpa; }

    // equals и toString — как раньше
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Student)) return false;
        Student other = (Student) obj;
        return name.equals(other.name) && age == other.age && Double.compare(gpa, other.gpa) == 0;
    }

    @Override
    public String toString() {
        return "Student{name='" + name + "', age=" + age + ", gpa=" + gpa + "}";
    }

    // Дополнительно: метод, который **может бросить IOException** (для демонстрации try-with-resources)
    public void saveToFile(String filename) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, true))) {
            writer.println(this.toString());
            System.out.println("Студент сохранён в файл: " + filename);
        }
        // close() вызывается автоматически благодаря try-with-resources
    }
}