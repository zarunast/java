package pr23_24;
import java.io.*;

public class Main {
    private static final String FILE_NAME = "student.ser";

    public static void main(String[] args) {
        // === 1. СОЗДАНИЕ ОБЪЕКТА ===
        Student original = new Student("Анна", 20, 4.8, "secret123");
        System.out.println("Оригинальный объект:");
        System.out.println(original);
        System.out.println();

        // === 2. СЕРИАЛИЗАЦИЯ В ФАЙЛ ===
        System.out.println("=== Сериализация ===");
        try (FileOutputStream fos = new FileOutputStream(FILE_NAME);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {

            oos.writeObject(original);
            System.out.println("✅ Объект успешно сериализован и сохранён в файл: " + FILE_NAME);

        } catch (IOException e) {
            System.err.println("❌ Ошибка при сериализации: " + e.getMessage());
            e.printStackTrace();
            return; // завершаем, если не удалось сохранить
        }

        System.out.println();

        // === 3. ДЕСЕРИАЛИЗАЦИЯ ИЗ ФАЙЛА ===
        System.out.println("=== Десериализация ===");
        Student restored = null;

        try (FileInputStream fis = new FileInputStream(FILE_NAME);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            restored = (Student) ois.readObject();
            System.out.println("✅ Объект успешно восстановлен из файла.");

        } catch (IOException e) {
            System.err.println("❌ Ошибка при чтении файла: " + e.getMessage());
            e.printStackTrace();
            return;
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Класс Student не найден при десериализации!");
            e.printStackTrace();
            return;
        }

        // === 4. ВЫВОД ВОССТАНОВЛЕННОГО ОБЪЕКТА ===
        System.out.println("\nВосстановленный объект:");
        System.out.println(restored);

        // === 5. АНАЛИЗ РЕЗУЛЬТАТА ===
        System.out.println("\n=== Анализ ===");
        System.out.println("🔹 Конструктор НЕ вызывался при десериализации (его вывода нет!)");
        System.out.println("🔹 Поле 'password' (transient) стало null — как и ожидалось.");
        System.out.println("🔹 Все остальные поля совпадают с оригиналом.");

        // Проверка значений
        if (original.getName().equals(restored.getName()) &&
                original.getAge() == restored.getAge() &&
                original.getGpa() == restored.getGpa()) {
            System.out.println("✅ Состояние объекта восстановлено корректно (кроме transient-полей).");
        } else {
            System.out.println("❌ Ошибка: данные не совпадают!");
        }

        System.out.println("\n✅ Работа завершена.");
    }
}