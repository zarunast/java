package pr23_24;
import java.io.Serializable;

public class Student implements Serializable {
    // Обязательно указываем serialVersionUID для контроля версий
    private static final long serialVersionUID = 1L;

    private String name;
    private int age;
    private double gpa;
    private transient String password; // не должен сериализоваться!

    // Конструктор (для обычного создания)
    public Student(String name, int age, double gpa, String password) {
        System.out.println("Конструктор Student вызван (только при обычном создании)!");
        this.name = name;
        this.age = age;
        this.gpa = gpa;
        this.password = password;
    }

    // Геттеры
    public String getName() { return name; }
    public int getAge() { return age; }
    public double getGpa() { return gpa; }
    public String getPassword() { return password; }

    @Override
    public String toString() {
        return "Student{name='" + name + "', age=" + age + ", gpa=" + gpa + ", password='" + password + "'}";
    }
}