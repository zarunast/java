package pr25;
// Student.java
public class Student {
    private String name;
    private int age;
    private double gpa;

    public Student(String name, int age, double gpa) throws InvalidStudentDataException {
        setName(name);
        setAge(age);
        setGpa(gpa);
    }

    public void setName(String name) throws InvalidStudentDataException {
        if (name == null || name.trim().isEmpty())
            throw new InvalidStudentDataException("Имя не может быть пустым");
        this.name = name.trim();
    }

    public void setAge(int age) throws InvalidStudentDataException {
        if (age < 14 || age > 100)
            throw new InvalidStudentDataException("Возраст должен быть от 14 до 100");
        this.age = age;
    }

    public void setGpa(double gpa) throws InvalidStudentDataException {
        if (gpa < 0 || gpa > 5.0)
            throw new InvalidStudentDataException("GPA должен быть в диапазоне [0, 5]");
        this.gpa = gpa;
    }

    // Геттеры
    public String getName() { return name; }
    public int getAge() { return age; }
    public double getGpa() { return gpa; }

    @Override
    public String toString() {
        return "Студент создан: " + name + ", возраст=" + age + ", GPA=" + gpa;
    }
}
