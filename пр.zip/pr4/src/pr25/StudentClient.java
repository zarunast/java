package pr25;
// StudentClient.java
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class StudentClient {
    public static void main(String[] args) {
        System.out.println("💬 Введите данные студента в формате: Имя Возраст GPA");
        System.out.println("Пример: Анна 20 4.5");

        Scanner scanner = new Scanner(System.in);
        String inputData = scanner.nextLine();
        scanner.close();

        try (Socket socket = new Socket("localhost", 5500)) {
            System.out.println("🟢 Подключились к серверу");

            OutputStream out = socket.getOutputStream();
            InputStream in = socket.getInputStream();

            PrintWriter writer = new PrintWriter(out, true, StandardCharsets.UTF_8);
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(in, StandardCharsets.UTF_8)
            );

            // Отправляем данные
            writer.println(inputData);
            System.out.println("📤 Отправлено: " + inputData);

            // Читаем ответ
            String response = reader.readLine();
            System.out.println("📥 Ответ сервера: " + response);

        } catch (IOException e) {
            System.err.println("❌ Не удалось подключиться к серверу: " + e.getMessage());
            System.out.println("Убедитесь, что сервер запущен!");
        }
    }
}