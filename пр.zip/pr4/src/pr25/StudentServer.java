package pr25;
// StudentServer.java
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class StudentServer {
    public static void main(String[] args) {
        System.out.println("✅ Сервер запущен. Ожидание подключения клиента на порту 5500...");

        try (ServerSocket serverSocket = new ServerSocket(5500)) {
            // Ожидаем подключение клиента
            Socket clientSocket = serverSocket.accept();
            System.out.println("🟢 Клиент подключился!");

            // Потоки ввода/вывода
            InputStream in = clientSocket.getInputStream();
            OutputStream out = clientSocket.getOutputStream();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(in, StandardCharsets.UTF_8)
            );
            PrintWriter writer = new PrintWriter(out, true, StandardCharsets.UTF_8);

            // Читаем строку от клиента
            String request = reader.readLine();
            System.out.println("📥 Получено от клиента: " + request);

            // Обрабатываем запрос
            String response = processStudentRequest(request);
            System.out.println("📤 Отправляем ответ: " + response);

            // Отправляем ответ
            writer.println(response);
            writer.flush();

            System.out.println("✅ Обработка завершена.");
        } catch (IOException e) {
            System.err.println("❌ Ошибка соединения: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Основной алгоритм обработки
    public static String processStudentRequest(String input) {
        try {
            // Ожидаем строку вида: "Анна 20 4.5"
            String[] parts = input.trim().split("\\s+");
            if (parts.length != 3) {
                return "Ошибка: ожидается 3 параметра (имя возраст GPA)";
            }

            String name = parts[0];
            int age = Integer.parseInt(parts[1]);
            double gpa = Double.parseDouble(parts[2]);

            // Создаём студента → возможна проверка через исключение
            Student student = new Student(name, age, gpa);
            return student.toString();

        } catch (NumberFormatException e) {
            return "Ошибка: возраст и GPA должны быть числами";
        } catch (InvalidStudentDataException e) {
            return "Ошибка валидации: " + e.getMessage();
        } catch (Exception e) {
            return "Неизвестная ошибка: " + e.getMessage();
        }
    }
}
