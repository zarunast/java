package pr3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int d = scanner.nextInt();
        int m = scanner.nextInt();
        boolean valid = false;
        if (m >= 1 && m <= 12) {
            if (m == 2) {
                valid = (d >= 1 && d <= 28);
            } else if (m == 4 || m == 6 || m == 9 || m == 11) {
                valid = (d >= 1 && d <= 30);
            } else {
                valid = (d >= 1 && d <= 31);
            }
        }
        System.out.println(valid ? "valid" : "invalid");
        int sum = scanner.nextInt();
        int discount;
        if (sum < 0) {
            System.out.println("invalid");
            return;
        }
        switch (sum / 1000) {  // группируем по тысячам
            case 0:
                discount = 0;
                break;
            case 1: case 2: case 3: case 4:
                discount = 5;
                break;
            default:
                discount = 10;
                break;
        }
        System.out.println(discount);
        double x = scanner.nextDouble();
        String sign = (x > 0) ? "+" :
                (x < 0) ? "-" : "0";
        System.out.println(sign);
    }
}

