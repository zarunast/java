package pr5;

import java.util.Scanner;

public class Main {
    public static double circleLength(double r){
        return 2*Math.PI*r;
    }
    public static double circleArea(double r){
        return Math.PI*r*r;
    }
    public static boolean isInieCircle(double r, double x1, double y1, double x2, double y2){
        double dx=x1-x2;
        double dy= y1-y2;
        return dx*dx+dy*dy<=r*r;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double r = scanner.nextDouble();
        double x1 = scanner.nextDouble();
        double y1 = scanner.nextDouble();
        double x2 = scanner.nextDouble();
        double y2 = scanner.nextDouble();
        System.out.println(circleLength(r));
        System.out.println(circleArea(r));
        System.out.println(isInieCircle(r,x1,x2,y1,y2));
    }
}