package pr6;

import pr7.logging.Logger;

public class FileLogger extends Logger {
    @Override
    public void log(String message) {

        System.out.println("Запись в файл: " + message);
    }
}
