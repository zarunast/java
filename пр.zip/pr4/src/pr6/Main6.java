package pr6;

import java.util.Random;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        book defaultBook = new book();
        System.out.println("Создана книга: " + defaultBook);

        System.out.print("Введите название книги: ");
        String USERtitle = scanner.nextLine();

        System.out.print("Введите количество страниц: ");
        int USERpages = scanner.nextInt();


        book paramBook = new book(USERtitle,USERpages);
        System.out.println("Создана книга: " + paramBook);

        book copyBook = new book(paramBook);
        System.out.println("Создана копия: " + copyBook);

        System.out.println("Книга '" + paramBook.title + "' большая? " + paramBook.isBig());
        System.out.println("Книга '" + defaultBook.title + "' большая? " + defaultBook.isBig());

        System.out.println("Кратко: " + paramBook.brief());
        System.out.println("Кратко: " + defaultBook.brief());

    }
}