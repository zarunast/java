package pr6;

public class book{
    String title;
    int pages;

    public book(){
        this("ABU", 200);
    }
    public book(String USERtitle,int USERpages){
        this.title=USERtitle;
        this.pages=USERpages;

    }
    public book(book otherBook){
//        this.title=otherBook.title;
//        this.pages=otherBook.pages;
        this(otherBook.title,otherBook.pages);
    }

/*
Методы:
● boolean isBig() – true, если страниц >300.
● String brief() – краткая информация: «Название (N стр.)»
 */
    public boolean isBig(){
        return pages>300;
    }

    public String brief(){
        return title+"("+pages+")";
    }

    @Override
    public String toString(){
        return "Книга: '" + title + "', страниц: " + pages;
    }
}


