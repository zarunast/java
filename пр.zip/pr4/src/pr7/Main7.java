package pr7;

import pr7.logging.Logger;
import pr6.FileLogger;

public class Main7 {
    public static void main(String[] args) {
        Logger logger = new Logger();
        FileLogger fileLogger = new FileLogger();

        System.out.println("Тестирование базового Logger:");
        logger.log("Обычный лог");
        logger.log("Ошибка", true);
        logger.log("Отладка", 1);
        logger.log("Предупреждение", 2);

        System.out.println("\nТестирование FileLogger:");
        fileLogger.log("Сообщение для записи в файл");
        fileLogger.log("Ошибка в файле", true);
        fileLogger.log("Уровень отладки", 1);
    }
}