package pr7.logging;

public class Logger {

    public void log(String message) {
        System.out.println("INFO: " + message);
    }

    public void log(String message, boolean isError) {
        if (isError) {
            System.out.println("ERROR: " + message);
        } else {
            log(message);
        }
    }

    public void log(String message, int level) {
        switch (level) {
            case 1:
                System.out.println("DEBUG: " + message);
                break;
            case 2:
                System.out.println("WARN: " + message);
                break;
            default:
                log(message);
        }
    }
}
