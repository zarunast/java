package pr8_11;

import java.util.*;

public class Main8 {
    public static void main(String[] args) {
        LinkedList<Service> services = new LinkedList<>();

        services.add(new Service("Базовый", 60, 500.0, 0));
        services.add(new InternetService("Оптика", 120, 800.0, 5.0, 200));
        services.add(new MobileService("Мобильный+", 30, 400.0, 15.0, 1200));

        services.addFirst(new Service("Стартовый", 30, 200.0, 10.0));
        services.addLast(new InternetService("Турбо", 240, 1200.0, 0, 500)); // в конец

        services.add(new MobileService("Эконом", 20, 150.0, 0, 200));

       services.removeIf(service -> service.getDiscountPercent() < 60);


        System.out.println("=== Весь список ===");
        for (Service s : services) {
            System.out.println(s);
        }

        // 3. Добавить в начало и конец → ещё раз
        services.addFirst(new Service("Новый старт", 15, 100.0, 0));
        services.addLast(new Service("Премиум", 180, 2000.0, 20.0));

        System.out.println("\n=== После добавления в начало и конец ===");
        services.forEach(System.out::println);

        // 4. Удалить первый и последний
        Service removedFirst = services.removeFirst();
        Service removedLast = services.removeLast();

        System.out.println("\nУдалён первый: " + removedFirst);
        System.out.println("Удалён последний: " + removedLast);

        // 5. Получить первый и последний без удаления
        System.out.println("\nПервый элемент (без удаления): " + services.getFirst());
        System.out.println("Последний элемент (без удаления): " + services.getLast());

        // 6. Найти первый элемент по условию: например, скидка > 10%
        Service firstWithDiscount = null;
        for (Service s : services) {
            if (s.getDiscountPercent() > 10) {
                firstWithDiscount = s;
                break;
            }
        }
        System.out.println("\nПервый с большой скидкой: " + firstWithDiscount);

        // 7. Удалить ВСЕ элементы с большой скидкой ( >10% )
        // ВАЖНО: удалять из списка в процессе итерации — через итератор!
        Iterator<Service> it = services.iterator();
        while (it.hasNext()) {
            if (it.next().getDiscountPercent() > 10) {
                it.remove();
            }
        }

        System.out.println("\n=== После удаления всех со скидкой >10% ===");
        services.forEach(System.out::println);

        // 8. Проверить, пуст ли список и вывести размер
        System.out.println("\nСписок пуст? " + services.isEmpty());
        System.out.println("Количество элементов: " + services.size());
    }
}