package pr8_11;

public class Service {
    private String tariff;          // Тариф
    private int durationMinutes;    // Время оказания (в минутах)
    private double baseCost;        // Базовая стоимость
    private double discountPercent; // Скидка в процентах (0–100)

    // Конструктор
    public Service(String tariff, int durationMinutes, double baseCost, double discountPercent) {
        setTariff(tariff);
        setDurationMinutes(durationMinutes);
        setBaseCost(baseCost);
        setDiscountPercent(discountPercent);
    }

    // Геттеры и сеттеры с валидацией

    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        if (tariff == null || tariff.trim().isEmpty())
            throw new IllegalArgumentException("Тариф не может быть пустым");
        this.tariff = tariff;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(int durationMinutes) {
        if (durationMinutes <= 0)
            throw new IllegalArgumentException("Время должно быть положительным");
        this.durationMinutes = durationMinutes;
    }

    public double getBaseCost() {
        return baseCost;
    }

    public void setBaseCost(double baseCost) {
        if (baseCost < 0)
            throw new IllegalArgumentException("Стоимость не может быть отрицательной");
        this.baseCost = baseCost;
    }

    public double getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(double discountPercent) {
        if (discountPercent < 0 || discountPercent > 100)
            throw new IllegalArgumentException("Скидка должна быть от 0 до 100%");
        this.discountPercent = discountPercent;
    }

    // Общий метод: итоговая стоимость с учётом скидки
    public double calculateFinalCost() {
        return baseCost * (1 - discountPercent / 100.0);
    }

    @Override
    public String toString() {
        return String.format("Услуга{тариф='%s', время=%d мин, цена=%.2f, скидка=%.1f%%, итог=%.2f}",
                tariff, durationMinutes, baseCost, discountPercent, calculateFinalCost());
    }
}
