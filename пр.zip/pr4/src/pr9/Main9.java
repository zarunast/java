package pr9;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main9 {
    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList<>();
        students.add(new Student("Анна", 20, 4.5));
        students.add(new Student("Борис", 22, 3.7));
        students.add(new Student("Вера", 19, 4.8));
        students.add(new Student("Глеб", 21, 3.2));
        students.add(new Student("Дина", 20, 4.9));






        // 2. Выводим весь список через for и for-each
        System.out.println("=== Вывод через обычный for ===");
        for (int i = 0; i < students.size(); i++) {
            System.out.println(students.get(i));
        }

        System.out.println("\n=== Вывод через for-each ===");
        for (Student s : students) {
            System.out.println(s);
        }

        // 3. Добавляем объект в начало и в конец
        students.add(0, new Student("Елена", 23, 4.0)); // в начало
        students.add(new Student("Жанна", 19, 4.6));    // в конец

        System.out.println("\nПосле добавления в начало и конец:");
        for (Student s : students) {
            System.out.println(s);
        }


        students.remove(1);

        Student gl = new Student("Глеб", 21, 3.2);
        students.remove(gl); // удаляем по значению

        System.out.println("\nПосле удаления по индексу и по значению:");
        for (Student s : students) {
            System.out.println(s);
        }
        System.out.println("\nТекущий размер списка: " + students.size());

        Student third = students.get(2);
        System.out.println("Имя третьего студента: " + third.getName());

        third.setGpa(5.0);

        System.out.println("После изменения GPA у третьего студента:");
        System.out.println(third);

        Student found = null;
        for (Student s : students) {
            if (s.getGpa() > 4.5) {
                found = s;
                break;
            }
        }
        if (found != null) {
            System.out.println("\nПервый студент с GPA > 4.5: " + found);
        } else {
            System.out.println("\nНет студентов с GPA > 4.5");
        }

        Student vera = new Student("Вера", 19, 5.0);
        System.out.println("Содержится ли Вера с GPA=5.0? " + students.contains(vera));

        students.clear();
        System.out.println("\nПосле clear(): размер списка = " + students.size());
    }
}